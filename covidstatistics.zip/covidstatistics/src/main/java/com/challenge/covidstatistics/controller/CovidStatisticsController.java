package com.challenge.covidstatistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.challenge.covidstatistics.response.Covid19Stats;
import com.challenge.covidstatistics.response.Data;
import com.challenge.covidstatistics.service.CovidStatisticsService;

@RestController
@RequestMapping("/api/covidStatistics")
public class CovidStatisticsController {
	
	@Autowired
	CovidStatisticsService covidStatisticsService;
	
	/**
	 * A GET API 
	 * which invokes Covid statistics API to fetch all the statistics world wide 
	 * @return 
	 * data if exists, else informational error message
	 */
	@GetMapping("/fetchAll")
	public ResponseEntity<?> fetchAll(){
		try {
			return new ResponseEntity<Data>(covidStatisticsService.fetchAll(), HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<String>("Fetching the data failed with reason "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * A GET API 
	 * which invokes Covid statistics API to fetch  the statistics by country 
	 * @return 
	 * data if exists, else informational error message
	 */
	@GetMapping("/fetchByCountry")
	public ResponseEntity<?> fetchByCountry(@RequestParam String country){
		try {
			return new ResponseEntity<Data>(covidStatisticsService.fetchByCountry(country), HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<String>("Fetching the data failed with reason "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	/**
	 * A GET API 
	 * which invokes Covid statistics API to fetch  the statistics by country and page size
	 * @return 
	 * data if exists, else informational error message
	 */
	@GetMapping("/fetchByCountryAndPageSize")
	public ResponseEntity<?> fetchByCountryAndPageSize(@RequestParam String country, @RequestParam int pageSize){
		try {
			return new ResponseEntity<List<Covid19Stats>>(covidStatisticsService.fetchByCountryAndPageSize(country,pageSize), HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<String>("Fetching the data failed with reason "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
