package com.challenge.covidstatistics.exception;

/**
 * Custom exception class 
 * for covid statistics application
 *
 */
public class ServiceException extends Exception {
	
	String message;
	String details;
	
	private static final long serialVersionUID = 1L;

	
	public ServiceException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public ServiceException(String msg){
		this.message=msg;
	}
	
	public ServiceException(String msg,String details){
		this.message=msg;
		this.details= details;
	}

}
