package com.challenge.covidstatistics.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.challenge.covidstatistics.exception.ServiceException;
import com.challenge.covidstatistics.response.Covid19Stats;
import com.challenge.covidstatistics.response.CovidStatisticsApiResponse;
import com.challenge.covidstatistics.response.Data;

@Service
public class CovidStatisticsService {
	
	private final String COVID_STATISTICS_BASE_URL="https://covid-19-coronavirus-statistics.p.rapidapi.com/v1/stats";
	@Autowired
	RestTemplate restTemplate;

	public Data fetchAll() throws ServiceException {
		HttpEntity<String> entity= getDefaultHttpEntity();
		ResponseEntity<CovidStatisticsApiResponse> response = restTemplate.exchange(
				COVID_STATISTICS_BASE_URL, HttpMethod.GET, entity,
				CovidStatisticsApiResponse.class);
		if(response!=null) {
			return response.getBody().getData();
		}
		throw new ServiceException("No data available");
	}

	public Data fetchByCountry(String country) throws ServiceException {
		HttpEntity<String> entity= getDefaultHttpEntity();
		ResponseEntity<CovidStatisticsApiResponse> response = restTemplate.exchange(COVID_STATISTICS_BASE_URL+"?country="+country, HttpMethod.GET, entity,
				CovidStatisticsApiResponse.class);
		if(response!=null) {
			return response.getBody().getData();
		}
		throw new ServiceException("No data available");
	}
	
	public List<Covid19Stats> fetchByCountryAndPageSize(String country, int pageSize) throws ServiceException {
		HttpEntity<String> entity= getDefaultHttpEntity();
		ResponseEntity<CovidStatisticsApiResponse> response = restTemplate.exchange(
				COVID_STATISTICS_BASE_URL+"?country="+country, HttpMethod.GET, entity,
				CovidStatisticsApiResponse.class);
		if(response!=null) {
			Data data= response.getBody().getData();
			return data.getCovid19Stats().stream().limit(pageSize).collect(Collectors.toList());
		}
		throw new ServiceException("No data available");
	}
	
	
	private HttpEntity<String> getDefaultHttpEntity() {
		final HttpHeaders headers = new HttpHeaders();
		headers.set("X-RapidAPI-Host", "covid-19-coronavirus-statistics.p.rapidapi.com");
		headers.set("X-RapidAPI-Key", "a79b6be05amsh9aeee16aeaebc21p18ce8bjsnb2cb559e8092");
		return new HttpEntity<String>(headers);		
	}
}
